<template>
  <div>
  <FireStote/>
  
  <!-- <h1>Hello This is vistas</h1> -->
</div>
</template>

<script>
import FireStote from '../components/FireStote.vue';

export default {
    name: 'IndexPage',
    components: { FireStote }
}
</script>

